namespace Triangle.Compiler.SyntaxTrees.Visitors
{
    public sealed class Void
    {
        Void()
        {
        }
    }
}