using Triangle.Compiler.CodeGenerator.Entities;

namespace Triangle.Compiler.SyntaxTrees.Declarations
{
    public interface IDeclaration
    {
       RuntimeEntity Entity { get; }
    }
}